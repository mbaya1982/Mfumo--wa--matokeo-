# KATULO MFUMO WA MATOKEO

Mfumo huu umeandaliwa kwa ajili ya shule nyingi, si shule moja.

Vipengele vilivyopangwa:
- Kuchagua shule
- Kutafuta kwa namba ya mtahiniwa
- Database ya shule, wanafunzi na matokeo
- Kila shule inaweza kupewa usimamizi wake
- Mfumo unaweza kufunguliwa kwenye Chrome kupitia GitHub Pages

MUHIMU:
GitHub Pages pekee haiwezi kuhifadhi database ya mtandaoni yenye kuandikwa na wasimamizi.
Ndio maana mfumo unahitaji backend/database kama Supabase.

Faili:
- index.html = ukurasa wa umma
- database.sql = muundo wa database
- README.txt = maelekezo

Hatua ya mwisho ya kuufanya uwe hai kabisa ni kuunganisha project ya Supabase na kuweka API URL/keys kwenye mfumo.
